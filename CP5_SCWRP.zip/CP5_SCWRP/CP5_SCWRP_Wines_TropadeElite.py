#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
| Arthur Costa Donaire | RM571283 |
| Felipe Pereira de Jesus | RM573263 |
| Giovanna Pereira de Oliveira | RM570989 |
| Gustavo Paiva Silva | RM572249 |
| Maria Eduarda Soares Lopes e Souza | RM572612 |

Checkpoint 5 - Statistical Computing with R & Python (parte Python)
Dataset: Wine  (https://www.kaggle.com/datasets/harrywang/wine-dataset-for-clustering)

Analisa duas variáveis quantitativas (Alcohol e Malic.acid):
  (a) Visualização: tabela de distribuição de frequências e histogramas
  (b) Análise descritiva: tendência central, dispersão e separatrizes (quartis)
  (c) Análise probabilística: distribuição Normal e cálculos de probabilidade

Uso:
    python estatistica_wines.py                       # lê ./wine.csv e salva figuras em ./figuras_estatistica
    python estatistica_wines.py --csv caminho/wine.csv --saida pasta_figuras
    python estatistica_wines.py --mostrar             # também abre as janelas dos gráficos

Dependências: numpy, pandas, matplotlib, scipy
"""
import argparse
import os
import sys
import warnings

import numpy as np
import pandas as pd
from scipy.stats import norm

# Paleta única para todos os gráficos: uma cor por variável analisada
CORES = {'Alcohol': '#7A1F3A', 'Malic.acid': '#C28A2E'}
COR_TRACO = '#2B2024'
VARIAVEIS = ['Alcohol', 'Malic.acid']


def titulo(texto):
    print('\n' + '=' * 78)
    print(texto)
    print('=' * 78)


def finalizar_figura(plt, fig, pasta, nome, mostrar):
    """Salva a figura em PNG e, se pedido, exibe na tela."""
    caminho = os.path.join(pasta, nome)
    fig.savefig(caminho, dpi=150, bbox_inches='tight')
    print(f'[figura salva] {caminho}')
    if mostrar:
        plt.show()
    plt.close(fig)


# ---------------------------------------------------------------------------
# (a) Tabela de distribuição de frequências + histograma
# ---------------------------------------------------------------------------
def tabela_frequencia(serie, bins=9):
    # Classes de mesma amplitude (pd.cut). 9 classes é coerente com a regra de
    # Sturges para n = 178: 1 + log2(178) = 8,5 -> 9 classes.
    classes = pd.cut(serie, bins=bins)
    freq = classes.value_counts().sort_index()
    out = pd.DataFrame({'Frequência': freq})
    out['Frequência relativa (%)'] = out['Frequência'] / len(serie) * 100
    out['Frequência acumulada'] = out['Frequência'].cumsum()
    out['Freq. rel. acumulada (%)'] = out['Frequência relativa (%)'].cumsum()
    return out


def parte_a(df, plt, pasta, mostrar):
    titulo('(a) VISUALIZAÇÃO DOS DADOS: TABELA DE FREQUÊNCIAS E HISTOGRAMAS')
    for col in VARIAVEIS:
        print(f'\n### {col}')
        print(tabela_frequencia(df[col]).round(2).to_string())

        fig = plt.figure(figsize=(8, 4))
        plt.hist(df[col], bins=9, edgecolor='white', color=CORES[col])
        plt.axvline(df[col].mean(), color=COR_TRACO, linestyle='--',
                    label=f'Média = {df[col].mean():.2f}')
        plt.axvline(df[col].median(), color=COR_TRACO, linestyle=':', linewidth=2,
                    label=f'Mediana = {df[col].median():.2f}')
        plt.title(f'Distribuição de {col}')
        plt.xlabel(col)
        plt.ylabel('Frequência')
        plt.legend()
        finalizar_figura(plt, fig, pasta, f'hist_{col}.png', mostrar)

    # Interpretação (Alcohol):
    #  - As 4 classes centrais (12,30 a 13,99) reúnem 115 dos 178 vinhos (64,6%); as classes
    #    extremas têm só 3 e 2 vinhos.
    #  - Média (13,00) ~ mediana (13,05): distribuição aproximadamente simétrica e concentrada.
    # Interpretação (Malic.acid):
    #  - A classe 1,30-1,86 concentra 68 vinhos (38,2%) e 50% dos vinhos (89 de 178) estão
    #    abaixo de 1,86; depois a frequência cai devagar até 5,80 (cauda longa à direita).
    #  - Média (2,34) > mediana (1,865): assimetria positiva (à direita).


# ---------------------------------------------------------------------------
# (b) Tendência central, dispersão e separatrizes (quartis)
# ---------------------------------------------------------------------------
def resumo_descritivo(serie):
    q1, q2, q3 = serie.quantile([0.25, 0.50, 0.75])
    return pd.Series({
        # Tendência central
        'Média': serie.mean(),
        'Mediana': serie.median(),
        'Moda': serie.mode().iloc[0],
        # Dispersão (variância e desvio padrão amostrais, ddof = 1)
        'Mínimo': serie.min(),
        'Máximo': serie.max(),
        'Amplitude': serie.max() - serie.min(),
        'Variância': serie.var(),
        'Desvio padrão': serie.std(),
        'Coef. variação (%)': serie.std() / serie.mean() * 100,  # compara escalas diferentes
        # Forma da distribuição
        'Assimetria (skew)': serie.skew(),
        # Separatrizes
        'Q1': q1, 'Q2': q2, 'Q3': q3,
        'IQR': q3 - q1,
    })


def parte_b(df, plt, pasta, mostrar):
    titulo('(b) ANÁLISE DESCRITIVA: TENDÊNCIA CENTRAL, DISPERSÃO E QUARTIS')
    resumo = pd.concat({v: resumo_descritivo(df[v]) for v in VARIAVEIS}, axis=1)
    print(resumo.round(4).to_string())

    # Interpretação:
    #  - Alcohol: média ~ mediana e assimetria ~ 0 (-0,05) -> simétrica; CV = 6,24% -> baixa
    #    dispersão relativa.
    #  - Malic.acid: média > mediana e assimetria positiva (1,04) -> cauda à direita; CV = 47,82%
    #    -> heterogeneidade quase 8 vezes maior que a de Alcohol.
    #  - O desvio padrão absoluto (0,81 x 1,12) esconde essa diferença; o CV corrige o efeito de
    #    escala e é a medida certa para comparar as duas variáveis.
    #  - Quartis: 50% dos vinhos têm Alcohol entre 12,36 e 13,68 (IQR = 1,32) e Malic.acid entre
    #    1,60 e 3,08 (IQR = 1,48). Em Malic.acid, Q2 (1,865) fica colada em Q1 (1,60): a metade
    #    superior é mais esticada, o que reforça a assimetria à direita.

    # Quartis em gráfico (boxplot) e valores atípicos (regra de Tukey: 1,5 x IQR)
    fig, axes = plt.subplots(2, 1, figsize=(8, 4))
    for ax, col in zip(axes, VARIAVEIS):
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')  # 'vert' foi renomeado em versões novas do matplotlib
            bp = ax.boxplot(df[col], vert=False, widths=0.6, patch_artist=True,
                            medianprops=dict(color=COR_TRACO, linewidth=2))
        bp['boxes'][0].set(facecolor=CORES[col], alpha=0.5, edgecolor=CORES[col])
        ax.set_yticks([])
        ax.set_xlabel(col)
    plt.suptitle('Boxplots: caixa = Q1 a Q3, traço escuro = mediana')
    plt.tight_layout()
    finalizar_figura(plt, fig, pasta, 'boxplots.png', mostrar)

    print()
    for col in VARIAVEIS:
        q1, q3 = df[col].quantile([0.25, 0.75])
        iqr = q3 - q1
        lim_inf, lim_sup = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        atipicos = df.loc[(df[col] < lim_inf) | (df[col] > lim_sup), col]
        print(f'{col}: limites de Tukey = [{lim_inf:.2f}; {lim_sup:.2f}] | '
              f'valores atípicos: {len(atipicos)} {sorted(atipicos.tolist())}')

    # Interpretação: em Alcohol a mediana fica no meio da caixa e não há valores atípicos. Em
    # Malic.acid a mediana está colada em Q1, a caixa se estende para a direita e 3 vinhos
    # (5,51; 5,65; 5,80) ficam acima do limite de Tukey (5,30): outra evidência da cauda à direita.


# ---------------------------------------------------------------------------
# (c) Distribuição de probabilidade: Normal com média e desvio padrão da amostra
# ---------------------------------------------------------------------------
# P(X > a)     = 1 - F(a)
# P(a < X < b) = F(b) - F(a),  em que F = função de distribuição acumulada (norm.cdf)
# Cada probabilidade teórica é comparada com a frequência empírica (proporção real no dataset).
def prob_normal_e_empirica(serie, tipo, a, b=None):
    mu, sigma = serie.mean(), serie.std()
    if tipo == 'acima':
        p_normal = 1 - norm.cdf(a, loc=mu, scale=sigma)
        p_emp = (serie > a).mean()
    else:
        p_normal = norm.cdf(b, loc=mu, scale=sigma) - norm.cdf(a, loc=mu, scale=sigma)
        p_emp = ((serie > a) & (serie < b)).mean()
    return p_normal, p_emp


def parte_c(df, plt, pasta, mostrar):
    titulo('(c) ANÁLISE PROBABILÍSTICA: DISTRIBUIÇÃO NORMAL E CÁLCULOS')
    for v in VARIAVEIS:
        print(f'{v} ~ Normal(média = {df[v].mean():.2f}; desvio padrão = {df[v].std():.2f})')

    calculos = [
        ('Alcohol', 'P(X > 13,5)', 'acima', 13.5, None),
        ('Alcohol', 'P(12,5 < X < 14,0)', 'entre', 12.5, 14.0),
        ('Malic.acid', 'P(X > 3,0)', 'acima', 3.0, None),
        ('Malic.acid', 'P(1,5 < X < 2,5)', 'entre', 1.5, 2.5),
    ]
    linhas = []
    for var, descricao, tipo, a, b in calculos:
        pn, pe = prob_normal_e_empirica(df[var], tipo, a, b)
        linhas.append([var, descricao, pn * 100, pe * 100, abs(pn - pe) * 100])
    prob = pd.DataFrame(linhas, columns=['Variável', 'Cálculo', 'Prob. normal (%)',
                                         'Freq. empírica (%)', 'Diferença (p.p.)'])
    print()
    print(prob.round(2).to_string(index=False))

    # Interpretação de cada cálculo (Normal x dados reais):
    #  - Alcohol P(X > 13,5): 26,92% x 30,90% -> a Normal subestima a cauda em 4,0 p.p.
    #  - Alcohol P(12,5 < X < 14,0): 62,21% x 55,62% -> a Normal superestima o miolo em 6,6 p.p.
    #    (ajuste razoável: diferenças de 4 a 7 p.p. para uma variável concentrada e simétrica).
    #  - Malic.acid P(X > 3,0): 27,62% x 26,40% -> cauda bem aproximada (1,2 p.p.).
    #  - Malic.acid P(1,5 < X < 2,5): 33,12% x 46,07% -> a Normal subestima o miolo em cerca de
    #    13 p.p.: os dados se acumulam abaixo de 1,9, mas a Normal é simétrica em torno da média.
    # Conclusão: a Normal é uma aproximação aceitável para Alcohol e limitada para Malic.acid
    # (assimetria à direita). Não foi aplicado teste formal de normalidade.

    # Curva Normal ajustada sobre os histogramas (densidade)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    for ax, col in zip(axes, VARIAVEIS):
        s = df[col]
        ax.hist(s, bins=9, density=True, color=CORES[col], alpha=0.55, edgecolor='white', label='Dados')
        x = np.linspace(s.min() - 0.5, s.max() + 0.5, 300)
        ax.plot(x, norm.pdf(x, s.mean(), s.std()), color=COR_TRACO, linewidth=2, label='Normal ajustada')
        ax.set_title(f'{col}: dados x Normal')
        ax.set_xlabel(col)
        ax.set_ylabel('Densidade')
        ax.legend()
    plt.tight_layout()
    finalizar_figura(plt, fig, pasta, 'normal_ajustada.png', mostrar)

    # Interpretação: em Alcohol a curva acompanha o formato de sino dos dados; em Malic.acid o pico
    # dos dados fica à esquerda da média e a cauda direita é mais longa, por isso a Normal não encaixa.


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description='Análise estatística do dataset Wine (Alcohol e Malic.acid).')
    ap.add_argument('--csv', default='wine.csv', help='caminho do wine.csv (padrão: ./wine.csv)')
    ap.add_argument('--saida', default='figuras_estatistica', help='pasta onde salvar as figuras')
    ap.add_argument('--mostrar', action='store_true', help='exibe os gráficos em janelas')
    args = ap.parse_args()

    if not os.path.exists(args.csv):
        sys.exit(f'Arquivo "{args.csv}" não encontrado. Baixe o dataset no Kaggle e salve como wine.csv.')

    import matplotlib
    if not args.mostrar:
        matplotlib.use('Agg')  # sem janelas: só salva os PNGs
    import matplotlib.pyplot as plt

    os.makedirs(args.saida, exist_ok=True)
    df = pd.read_csv(args.csv)
    print(f'Linhas: {df.shape[0]} | Colunas: {df.shape[1]}')
    print('Valores nulos no dataset:', df.isnull().sum().sum())  # 0 -> sem dados ausentes
    print(f'Variáveis analisadas: {", ".join(VARIAVEIS)}')

    parte_a(df, plt, args.saida, args.mostrar)
    parte_b(df, plt, args.saida, args.mostrar)
    parte_c(df, plt, args.saida, args.mostrar)
    print('\nAnálise concluída.')


if __name__ == '__main__':
    main()
